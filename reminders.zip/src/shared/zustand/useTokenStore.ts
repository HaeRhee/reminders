import { create } from "zustand";

type TokenType = {
  accessToken: string;
  setTokenData: (accessToken: string) => void;
};

const tokenState = {
  accessToken: "",
};

export const useTokenStore = create<TokenType>((set) => ({
  ...tokenState,
  setTokenData: (accessToken: string) => {
    set({ accessToken });
  },
}));
