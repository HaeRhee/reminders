export const QUERYKEY_TODOLIST = {
  todos: "todos",
};
