export const QUERYKEY_SIGNUP = {
  ADD_USER: "AddUser",
};
