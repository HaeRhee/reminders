import { register } from "@src/types/signup";
import axios from "axios";

export const authApi = axios.create({
  baseURL: "http://localhost:8000",
  headers: {
    "Content-Type": "application/json",
  },
});

export const loginApi = {
  getSignup: () => authApi.get("/users"),
};

export const signupApi = {
  postSignup: (payload: register) => authApi.post("/register", payload),
};
