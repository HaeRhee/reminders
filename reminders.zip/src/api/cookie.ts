import { Cookies } from "react-cookie";

const cookies = new Cookies();

// export const useCookies = () => {
export const setCookie = (name: string, value: string, option: object) => {
  return cookies.set(name, value, { ...option });
};

export const getCookie = (name: string) => {
  return cookies.get(name);
};

export const removeCookie = (name: string, option?: object) => {
  return cookies.remove(name, { ...option });
};
//   return { setCookie, getCookie, removeCookie };
// };
