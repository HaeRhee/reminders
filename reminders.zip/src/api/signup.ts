import { register } from "@src/types/signup";
import { signupApi } from "./auth";
import axios from "axios";
import { Router } from "react-router-dom";

export const signupApiHandle = async ({
  email,
  password,
  nickname,
}: register) => {
  try {
    const response = await signupApi.postSignup({
      email,
      password,
      nickname,
    });

    return response;
  } catch (error) {
    if (axios.isAxiosError(error) && error.response) {
      const errorMessage = error.response.data;
      if (errorMessage === "Email already exists")
        throw Error("이미 있는 이메일 입니다");
    }
  }
};
