import { useMutation, useQueryClient } from "@tanstack/react-query";
import { signupApiHandle } from "@src/api/signup";
import { QUERYKEY_SIGNUP } from "@src/queryKey/signup";

// signup mutation collection
export const useSignupMutation = () => {
  const queryClient = useQueryClient();
  const addUserMutation = useMutation({
    mutationFn: signupApiHandle,
    onSuccess: () =>
      queryClient.invalidateQueries({
        queryKey: [QUERYKEY_SIGNUP],
      }),
  });

  return { addUserMutation };
};
