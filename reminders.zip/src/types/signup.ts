export interface register {
  email: string;
  password: string;
  nickname: string;
}
