export type Todolist = {
  id: string;
  name: string;
  email: string;
};
