import { ChangeEvent, FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { loginApi } from "@src/api/auth";
import { setCookie } from "@src/api/cookie";
import { register } from "@src/types/signup";

export type OnChangeType = {
  name: string;
  value: string;
};

const Login = () => {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    email: "",
    password: "",
  });
  const { email, password } = form;

  const onChangeHandle = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value }: OnChangeType = e.target;
    setForm((preForm) => ({ ...preForm, [name]: value }));
  };

  const onLoginHandle = async (e: FormEvent) => {
    e.preventDefault();

    try {
      const response = await loginApi.getSignup();
      const userDatas = response.data;
      const targetUserData = userDatas.find((user: register) => user.email);
      const {
        email: userEmail,
        nickname,
      }: { email: string; nickname: string } = targetUserData;
      const token = response.data.accessToken;
      console.log(token);
      if (!response.data.accessToken) {
        alert("토큰이 없습니다. 문의해주세요.");
        return;
      }

      alert("로그인에 성공하였습니다. 메인 페이지로 이동할게용");
      if (response.data.accessToken) {
        const token = response.data.accessToken;
        console.log("토큰 나왔엉");
        setCookie("accessToken", token, {
          path: "/",
          httpOnly: true,
          secure: true,
          sameSite: true,
        });
        setCookie("email", userEmail, { path: "/" });
        setCookie("nickname", nickname, { path: "/" });

        navigate("/");
      }
    } catch (error) {
      throw Error("error");
    }
  };

  return (
    <div>
      <h1>로그인</h1>
      <main>
        <section className="text-black">
          <form onSubmit={onLoginHandle}>
            <div>
              <label htmlFor="email">email</label>
              <input
                type="string"
                id="email"
                name="email"
                value={email}
                onChange={onChangeHandle}
              />
            </div>

            <div>
              <label htmlFor="password">Password</label>
              <input
                type="password"
                id="password"
                name="password"
                value={password}
                onChange={onChangeHandle}
              />
            </div>

            <button type="submit">로그인</button>
            <button
              type="button"
              onClick={() => {
                navigate("/signup");
              }}
            >
              회원가입
            </button>
            <button
              type="button"
              onClick={() => {
                navigate("/");
              }}
            >
              홈으로
            </button>
          </form>
        </section>
      </main>
    </div>
  );
};

export default Login;
