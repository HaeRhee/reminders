import { ChangeEvent, FormEvent, useState } from "react";
import { useNavigate } from "react-router-dom";
import { signupApi } from "@src/api/auth";
import { OnChangeType } from "./Login";
import axios from "axios";
import { useSignupMutation } from "@src/mutations/signup";

const SignUp = () => {
  const navigate = useNavigate();
  const { addUserMutation } = useSignupMutation();
  const [form, setForm] = useState({
    email: "",
    password: "",
    nickname: "",
  });
  const { email, password, nickname } = form;

  const onChangeHandle = (e: ChangeEvent<HTMLInputElement>) => {
    const { name, value }: OnChangeType = e.target;
    setForm((preForm) => ({ ...preForm, [name]: value }));
  };

  const onSignupHandle = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const response = await signupApi.postSignup({
        email,
        password,
        nickname,
      });
      console.log(response);

      if (response.data.success) {
        console.log(response.data.success);
        alert("회원가입에 성공하였습니다. 로그인 페이지로 이동할게용");
        navigate("/login");
      }
    } catch (error) {
      if (axios.isAxiosError(error) && error.response) {
        const errorMessage = error.response.data;
        if (errorMessage === "Email already exists")
          throw Error("이미 있는 이메일 입니다");
      }
    }
  };

  return (
    <div>
      <h1>회원가입</h1>
      <main>
        <form onSubmit={onSignupHandle}>
          <div>
            <label htmlFor="email">email</label>
            <input
              type="string"
              id="email"
              name="email"
              value={email}
              onChange={onChangeHandle}
            />
          </div>

          <div>
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              name="password"
              value={password}
              onChange={onChangeHandle}
            />
          </div>

          <div>
            <label htmlFor="nickname">nickname</label>
            <input
              type="nickname"
              id="nickname"
              name="nickname"
              value={nickname}
              onChange={onChangeHandle}
            />
          </div>

          <button type="submit">회원가입</button>
          <button
            type="button"
            onClick={() => {
              navigate("/signup");
            }}
          >
            회원가입
          </button>
          <button
            type="button"
            onClick={() => {
              navigate("/");
            }}
          >
            홈으로
          </button>
        </form>
      </main>
    </div>
  );
};

export default SignUp;
